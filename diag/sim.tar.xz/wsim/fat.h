#pragma once
typedef struct {int x;} DISC_INTERFACE;
int fatMountSimple(const char*, const DISC_INTERFACE*);
