/* Simulateur GX logiciel : execute le code de dessin de main.c sur PC et
   ecrit l'image en PPM. Echantillonnage au centre des pixels (comme la
   GameCube sans anticrenelage), texture I4 decodee depuis son format en tuiles. */
#define main gc_main
#include "../web/source/main.c"
#undef main
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define W 640
#define H 480
static float fb[H][W][3];
static float tex[FONT_TEX_H][FONT_TEX_W];
static int numtexgens = 0;
static int cur_map = 0;
static int sc_x0 = 0, sc_y0 = 0, sc_x1 = 640, sc_y1 = 480;
static GXTexObj sim_t2;
static int blend_on = 1;
static long prims = 0, verts_total = 0;

typedef struct { float x, y, r, g, b, a, u, v; } V;
static V vb[4096];
static int nv = 0, prim = 0;

static void decode_i4(void) {
    /* la GameCube est gros-boutiste : octet 0 d'un mot = bits 31..24 */
    static u8 d[sizeof(font_tex)];
    for (size_t i = 0; i < sizeof(font_tex) / 4; i++) {
        d[4*i] = font_tex[i] >> 24; d[4*i+1] = font_tex[i] >> 16; d[4*i+2] = font_tex[i] >> 8; d[4*i+3] = font_tex[i];
    }
    int tilesx = FONT_TEX_W / 8;
    for (int y = 0; y < FONT_TEX_H; y++)
        for (int x = 0; x < FONT_TEX_W; x++) {
            int t = (y / 8) * tilesx + (x / 8);
            int off = t * 32 + (y % 8) * 4 + (x % 8) / 2;
            int nib = (x & 1) ? (d[off] & 15) : (d[off] >> 4);
            tex[y][x] = nib / 15.0f;
        }
}
static float sample(float u, float v) {          /* bilineaire, CLAMP */
    float fx = u * FONT_TEX_W - 0.5f, fy = v * FONT_TEX_H - 0.5f;
    int x0 = (int)floorf(fx), y0 = (int)floorf(fy);
    float ax = fx - x0, ay = fy - y0;
    float s = 0;
    for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
        int xx = x0 + i, yy = y0 + j;
        if (xx < 0) xx = 0; if (yy < 0) yy = 0;
        if (xx >= FONT_TEX_W) xx = FONT_TEX_W - 1; if (yy >= FONT_TEX_H) yy = FONT_TEX_H - 1;
        s += tex[yy][xx] * (i ? ax : 1 - ax) * (j ? ay : 1 - ay);
    }
    return s;
}
static void raster(V *a, V *b, V *c) {
    float minx = fminf(a->x, fminf(b->x, c->x)), maxx = fmaxf(a->x, fmaxf(b->x, c->x));
    float miny = fminf(a->y, fminf(b->y, c->y)), maxy = fmaxf(a->y, fmaxf(b->y, c->y));
    float area = (b->x - a->x) * (c->y - a->y) - (b->y - a->y) * (c->x - a->x);
    if (fabsf(area) < 1e-6f) return;
    int x0 = (int)floorf(minx), x1 = (int)ceilf(maxx), y0 = (int)floorf(miny), y1 = (int)ceilf(maxy);
    if (x0 < 0) x0 = 0; if (y0 < 0) y0 = 0; if (x1 > W) x1 = W; if (y1 > H) y1 = H;
    if (x0 < sc_x0) x0 = sc_x0; if (y0 < sc_y0) y0 = sc_y0; if (x1 > sc_x1) x1 = sc_x1; if (y1 > sc_y1) y1 = sc_y1;
    for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) {
        float px = x + 0.5f, py = y + 0.5f;
        float w0 = ((b->x - px) * (c->y - py) - (b->y - py) * (c->x - px)) / area;
        float w1 = ((c->x - px) * (a->y - py) - (c->y - py) * (a->x - px)) / area;
        float w2 = 1 - w0 - w1;
        /* regle "haut-gauche" approchee : on inclut les bords */
        if (w0 < -1e-6f || w1 < -1e-6f || w2 < -1e-6f) continue;
        float r = w0 * a->r + w1 * b->r + w2 * c->r;
        float g = w0 * a->g + w1 * b->g + w2 * c->g;
        float bb = w0 * a->b + w1 * b->b + w2 * c->b;
        float al = w0 * a->a + w1 * b->a + w2 * c->a;
        if (numtexgens && cur_map == 2) {      /* image web RGB5A3 tuilee 4x4, au plus proche */
            float u = w0 * a->u + w1 * b->u + w2 * c->u, v = w0 * a->v + w1 * b->v + w2 * c->v;
            u16 *tp; memcpy(&tp, &sim_t2.dummy[0], sizeof(tp)); int tw = sim_t2.dummy[2], th = sim_t2.dummy[3];
            int xx = (int)(u * tw), yy = (int)(v * th); if (xx < 0) xx = 0; if (yy < 0) yy = 0; if (xx >= tw) xx = tw - 1; if (yy >= th) yy = th - 1;
            u16 t = tp[((yy >> 2) * (tw >> 2) + (xx >> 2)) * 16 + (yy & 3) * 4 + (xx & 3)];
            float ta;
            if (t & 0x8000) { r = ((t >> 10) & 31) / 31.f; g = ((t >> 5) & 31) / 31.f; bb = (t & 31) / 31.f; ta = 1; }
            else { ta = ((t >> 12) & 7) / 7.f; r = ((t >> 8) & 15) / 15.f; g = ((t >> 4) & 15) / 15.f; bb = (t & 15) / 15.f; }
            al *= ta;
        } else
        if (numtexgens && cur_map == 1) {      /* pochette RGB565 tuilee 4x4, bilineaire */
            float u = w0 * a->u + w1 * b->u + w2 * c->u, v = w0 * a->v + w1 * b->v + w2 * c->v;
            float fx = u * COVER_SZ - 0.5f, fy = v * COVER_SZ - 0.5f;
            int x0 = (int)floorf(fx), y0 = (int)floorf(fy);
            float ax = fx - x0, ay = fy - y0, acc[3] = {0, 0, 0};
            for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
                int xx = x0 + i, yy = y0 + j;
                if (xx < 0) xx = 0; if (yy < 0) yy = 0; if (xx >= COVER_SZ) xx = COVER_SZ - 1; if (yy >= COVER_SZ) yy = COVER_SZ - 1;
                u16 t = cover_tex[((yy >> 2) * (COVER_SZ / 4) + (xx >> 2)) * 16 + (yy & 3) * 4 + (xx & 3)];
                float wt = (i ? ax : 1 - ax) * (j ? ay : 1 - ay);
                acc[0] += wt * ((t >> 11) & 31) / 31.f; acc[1] += wt * ((t >> 5) & 63) / 63.f; acc[2] += wt * (t & 31) / 31.f;
            }
            r = acc[0]; g = acc[1]; bb = acc[2];
        } else if (numtexgens) {
            float u = w0 * a->u + w1 * b->u + w2 * c->u, v = w0 * a->v + w1 * b->v + w2 * c->v;
            al *= sample(u, v);
        }
        if (!blend_on) al = 1;
        for (int k = 0; k < 3; k++) {
            float s = (k == 0 ? r : k == 1 ? g : bb);
            fb[y][x][k] = s * al + fb[y][x][k] * (1 - al);
        }
    }
}

/* --- API GX simulee --- */
void GX_Begin(u8 p, u8 f, u16 n) { prim = p; nv = 0; (void)f; (void)n; prims++; }
static f32 vp_x = 0, vp_y = 0, vp_w = 640, vp_h = 480, pr_l = 0, pr_r = 640;
void GX_Position2f32(f32 x, f32 y) { nv++; vb[nv - 1].x = vp_x + (x - pr_l) * vp_w / (pr_r - pr_l); vb[nv - 1].y = vp_y + y * vp_h / 480.0f; }
void GX_Color4u8(u8 r, u8 g, u8 b, u8 a) { V *v = &vb[nv - 1]; v->r = r / 255.f; v->g = g / 255.f; v->b = b / 255.f; v->a = a / 255.f; }
void GX_TexCoord2f32(f32 s, f32 t) { vb[nv - 1].u = s; vb[nv - 1].v = t; }
int sim_noraster = 0;
void GX_End(void) {
    verts_total += nv;
    if (sim_noraster) return;
    if (prim == GX_QUADS) for (int i = 0; i + 3 < nv; i += 4) { raster(&vb[i], &vb[i+1], &vb[i+2]); raster(&vb[i], &vb[i+2], &vb[i+3]); }
    else if (prim == GX_TRIANGLES) for (int i = 0; i + 2 < nv; i += 3) raster(&vb[i], &vb[i+1], &vb[i+2]);
    else if (prim == GX_TRIANGLEFAN) for (int i = 1; i + 1 < nv; i++) raster(&vb[0], &vb[i], &vb[i+1]);
    else if (prim == GX_TRIANGLESTRIP) for (int i = 0; i + 2 < nv; i++) raster(&vb[i], &vb[i+1], &vb[i+2]);
}
void GX_SetNumTexGens(u32 n) { numtexgens = (int)n; }
void GX_SetBlendMode(u8 m, u8 a, u8 b, u8 c) { blend_on = (m == GX_BM_BLEND); }
static const char *outname = "out.ppm";
void GX_CopyDisp(void *d, u8 c) {
    if (sim_noraster) return;
    FILE *f = fopen(outname, "wb");
    fprintf(f, "P6\n%d %d\n255\n", W, H);
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) for (int k = 0; k < 3; k++) {
        float v = fb[y][x][k]; if (v < 0) v = 0; if (v > 1) v = 1; fputc((int)(v * 255 + 0.5f), f);
    }
    fclose(f);
    memset(fb, 0, sizeof(fb));
}
/* le reste ne fait rien */
void *GX_Init(void *a, u32 b) { return a; } void GX_SetCopyClear(GXColor a, u32 b) {} void GX_SetViewport(f32 a, f32 b, f32 c, f32 d, f32 e, f32 f) { vp_x = a; vp_y = b; vp_w = c; vp_h = d; }
/* ---- v35 : fausses cartes memoire (slot A : 3 sauvegardes ; slot B : vide ; erreur possible) ---- */
static u8 sim_arena[1 << 16];
void *SYS_GetArena1Lo(void) { return sim_arena; } void *SYS_GetArena1Hi(void) { return sim_arena + sizeof(sim_arena); }
typedef struct { int used; card_direntry de; u8 *data; } simcf;
static simcf sim_card[2][CARD_MAXFILES];
int sim_card_err[2] = { 0, 0 };
static char sim_gc[5] = "GMP3", sim_co[3] = "GC";
s32 CARD_Init(const char *g, const char *c) { return 0; }
s32 CARD_Mount(s32 chn, void *w, cardcallback cb) { return sim_card_err[chn]; }
s32 CARD_Unmount(s32 chn) { return 0; }
s32 CARD_GetSectorSize(s32 chn, u32 *s) { *s = 8192; return 0; }
s32 CARD_GetFreeBlocks(s32 chn, u16 *f) { int u = 0; for (int i = 0; i < CARD_MAXFILES; i++) if (sim_card[chn][i].used) u += sim_card[chn][i].de.length; *f = (u16)(251 - u); return 0; }
s32 CARD_SetCompany(const char *c) { snprintf(sim_co, 3, "%s", c ? c : ""); return 0; }
s32 CARD_SetGamecode(const char *g) { snprintf(sim_gc, 5, "%s", g ? g : ""); return 0; }
static int sim_find_from(int chn, int i) { for (; i < CARD_MAXFILES; i++) if (sim_card[chn][i].used) return i; return -1; }
static void sim_fill_dir(int chn, int i, card_dir *d) { simcf *f = &sim_card[chn][i]; d->chn = chn; d->fileno = i; d->filelen = f->de.length * 8192; memcpy(d->filename, f->de.filename, 32); memcpy(d->gamecode, f->de.gamecode, 4); memcpy(d->company, f->de.company, 2); }
s32 CARD_FindFirst(s32 chn, card_dir *d, bool all) { int i = sim_find_from(chn, 0); if (i < 0) return CARD_ERROR_NOFILE; sim_fill_dir(chn, i, d); return 0; }
s32 CARD_FindNext(card_dir *d) { int i = sim_find_from(d->chn, d->fileno + 1); if (i < 0) return CARD_ERROR_NOFILE; sim_fill_dir(d->chn, i, d); return 0; }
s32 CARD_GetStatusEx(s32 chn, s32 n, card_direntry *e) { if (!sim_card[chn][n].used) return CARD_ERROR_NOFILE; *e = sim_card[chn][n].de; return 0; }
s32 CARD_SetStatusEx(s32 chn, s32 n, card_direntry *e) { if (!sim_card[chn][n].used) return CARD_ERROR_NOFILE; card_direntry *d = &sim_card[chn][n].de; d->banner_fmt = e->banner_fmt; d->last_modified = e->last_modified; d->icon_addr = e->icon_addr; d->icon_fmt = e->icon_fmt; d->icon_speed = e->icon_speed; d->permission = e->permission; d->copy_times = e->copy_times; d->comment_addr = e->comment_addr; return 0; }
s32 CARD_OpenEntry(s32 chn, card_dir *d, card_file *f) { if (!sim_card[chn][d->fileno].used) return CARD_ERROR_NOFILE; f->chn = chn; f->filenum = d->fileno; f->len = sim_card[chn][d->fileno].de.length * 8192; return 0; }
s32 CARD_Close(card_file *f) { return 0; }
s32 CARD_Read(card_file *f, void *b, u32 len, u32 off) { simcf *c = &sim_card[f->chn][f->filenum]; if (off + len > (u32)c->de.length * 8192) return CARD_ERROR_FATAL_ERROR; memcpy(b, c->data + off, len); return 0; }
s32 CARD_Write(card_file *f, void *b, u32 len, u32 off) { simcf *c = &sim_card[f->chn][f->filenum]; if (len % 8192 || off + len > (u32)c->de.length * 8192) return CARD_ERROR_FATAL_ERROR; memcpy(c->data + off, b, len); return 0; }
s32 CARD_Create(s32 chn, const char *nm, u32 size, card_file *f) {
    int fr = -1;
    for (int i = 0; i < CARD_MAXFILES; i++) {
        simcf *c = &sim_card[chn][i];
        if (!c->used) { if (fr < 0) fr = i; continue; }
        if (!strncmp((char *)c->de.filename, nm, 32) && !memcmp(c->de.gamecode, sim_gc, 4) && !memcmp(c->de.company, sim_co, 2)) return CARD_ERROR_EXIST;
    }
    if (fr < 0) return CARD_ERROR_NOENT;
    u16 fb; CARD_GetFreeBlocks(chn, &fb); if (size / 8192 > fb) return CARD_ERROR_INSSPACE;
    simcf *c = &sim_card[chn][fr]; memset(c, 0, sizeof(*c)); c->used = 1;
    memcpy(c->de.gamecode, sim_gc, 4); memcpy(c->de.company, sim_co, 2); strncpy((char *)c->de.filename, nm, 32);
    c->de.length = size / 8192; c->de.icon_addr = 0xFFFFFFFF; c->de.comment_addr = 0xFFFFFFFF; c->de.permission = 4; c->data = calloc(1, size);
    f->chn = chn; f->filenum = fr; f->len = size; printf("CARTE %c : creee %s (%u blocs)\n", 'A' + chn, nm, size / 8192); return 0;
}
s32 CARD_DeleteEntry(s32 chn, card_dir *d) { simcf *c = &sim_card[chn][d->fileno]; if (!c->used) return CARD_ERROR_NOFILE; free(c->data); c->used = 0; printf("CARTE %c : supprimee %s\n", 'A' + chn, d->filename); return 0; }
/* une sauvegarde de test : commentaire + icone RGB5A3 ou CI8 */
void sim_card_add(int chn, const char *gc, const char *co, const char *nm, int blocks, const char *t1, const char *t2, int ci) {
    for (int i = 0; i < CARD_MAXFILES; i++) {
        simcf *c = &sim_card[chn][i]; if (c->used) continue;
        memset(c, 0, sizeof(*c)); c->used = 1;
        memcpy(c->de.gamecode, gc, 4); memcpy(c->de.company, co, 2); strncpy((char *)c->de.filename, nm, 32);
        c->de.length = blocks; c->data = calloc(1, blocks * 8192); c->de.pad_00 = 0xFF; c->de.pad_01 = 0xFFFF; c->de.permission = 4;
        c->de.comment_addr = 0; strncpy((char *)c->data, t1, 32); strncpy((char *)c->data + 32, t2, 32);
        c->de.banner_fmt = 2; c->de.icon_addr = 64;               /* banniere RGB 96x32 puis icone */
        u32 io = 64 + 96 * 32 * 2;
        if (!ci) { c->de.icon_fmt = 2; c->de.icon_speed = 1; for (int p = 0; p < 1024; p++) { u16 v = 0x8000 | ((p & 31) << 10) | (((p >> 5) & 31) << 5) | 31; c->data[io + p * 2] = v >> 8; c->data[io + p * 2 + 1] = v; } }
        else { c->de.icon_fmt = 3; c->de.icon_speed = 1; for (int p = 0; p < 1024; p++) c->data[io + p] = (u8)(p & 255); for (int k = 0; k < 256; k++) { u16 v = 0x8000 | (k << 7); c->data[io + 1024 + k * 2] = v >> 8; c->data[io + 1024 + k * 2 + 1] = v; } }
        for (int b = 1; b < blocks; b++) c->data[b * 8192] = (u8)b;
        return;
    }
}
int sim_lang = 2; u8 SYS_GetLanguage(void) { const char *e = getenv("SIM_LANG"); return (u8)(e ? atoi(e) : sim_lang); }
void SYS_SetLanguage(u8 l) { sim_lang = l; printf("SRAM langue=%d\n", l); }
u8 sim_sound = 1; u8 SYS_GetSoundMode(void) { return sim_sound; } void SYS_SetSoundMode(u8 m) { sim_sound = m; printf("SRAM son=%d\n", m); }
s8 sim_hoff = 0; s8 SYS_GetDisplayOffsetH(void) { return sim_hoff; } void SYS_SetDisplayOffsetH(s8 o) { sim_hoff = o; printf("SRAM position=%d\n", o); }

f32 GX_GetYScaleFactor(u16 a, u16 b) { return 1; } u32 GX_SetDispCopyYScale(f32 a) { return 480; } void GX_SetScissor(u32 a, u32 b, u32 c, u32 d) { sc_x0 = a; sc_y0 = b; sc_x1 = a + c; sc_y1 = b + d; }
void GX_SetDispCopySrc(u16 a, u16 b, u16 c, u16 d) {} void GX_SetDispCopyDst(u16 a, u16 b) {} void GX_SetCopyFilter(u8 a, u8 (*b)[2], u8 c, u8 *d) {}
void GX_SetFieldMode(u8 a, u8 b) {} void GX_SetPixelFmt(u8 a, u8 b) {} void GX_SetCullMode(u8 a) {} void GX_SetDispCopyGamma(u8 a) {}
void guOrtho(Mtx44 m, f32 a, f32 b, f32 c, f32 d, f32 e, f32 f) { m[0][0] = c; m[0][1] = d; } void GX_LoadProjectionMtx(Mtx44 m, u8 t) { pr_l = m[0][0]; pr_r = m[0][1]; } void guMtxIdentity(Mtx m) {}
void GX_LoadPosMtxImm(Mtx m, u32 i) {} void GX_SetCurrentMtx(u32 i) {} void GX_SetZMode(u8 a, u8 b, u8 c) {}
void GX_SetColorUpdate(u8 a) {} void GX_SetAlphaUpdate(u8 a) {} void GX_SetNumChans(u8 a) {} void GX_SetChanCtrl(s32 a, u8 b, u8 c, u8 d, u8 e, u8 f, u8 g) {}
void GX_SetNumTevStages(u8 a) {} void GX_ClearVtxDesc(void) {} void GX_SetVtxDesc(u8 a, u8 b) {} void GX_SetVtxAttrFmt(u8 a, u32 b, u32 c, u32 d, u32 e) {}
void GX_InitTexObj(GXTexObj *o, void *p, u16 w, u16 h, u8 f, u8 s, u8 t, u8 m) { memcpy(&o->dummy[0], &p, sizeof(p)); o->dummy[2] = w; o->dummy[3] = h; o->dummy[4] = f; } void GX_InitTexObjFilterMode(GXTexObj *o, u8 a, u8 b) {}
void GX_InvalidateTexAll(void) {} void GX_LoadTexObj(GXTexObj *o, u8 m) { if (m == 2) sim_t2 = *o; } void GX_InvVtxCache(void) {}
void GX_SetTevOrder(u8 a, u8 b, u32 c, u8 d) { cur_map = (int)c; } void GX_SetTevOp(u8 a, u8 b) {} void GX_SetTexCoordGen(u16 a, u32 b, u32 c, u32 d) {}
void GX_SetTevColorIn(u8 s, u8 a, u8 b, u8 c, u8 d) {} void GX_SetTevColorOp(u8 s, u8 a, u8 b, u8 c, u8 d, u8 e) {}
void GX_SetTevAlphaIn(u8 s, u8 a, u8 b, u8 c, u8 d) {} void GX_SetTevAlphaOp(u8 s, u8 a, u8 b, u8 c, u8 d, u8 e) {}
void GX_DrawDone(void) {}
static GXDrawDoneCallback ddcb;
GXDrawDoneCallback GX_SetDrawDoneCallback(GXDrawDoneCallback c) { GXDrawDoneCallback o = ddcb; ddcb = c; return o; }
void GX_SetDrawDone(void) { if (ddcb) ddcb(); }
void GX_GetGPStatus(u8 *a, u8 *b, u8 *c, u8 *d, u8 *e) { *a = *b = *c = *d = *e = 0; }
static GXRModeObj mode = { 0, 640, 480, 480, 0, 0, 640, 480, 0, 0, 0, {{0}}, {0} };
void VIDEO_Init(void) {} GXRModeObj *VIDEO_GetPreferredMode(GXRModeObj *m) { return &mode; } void *SYS_AllocateFramebuffer(GXRModeObj *m) { return malloc(640 * 480 * 2); }
void VIDEO_Configure(GXRModeObj *m) {} void VIDEO_ClearFrameBuffer(GXRModeObj *m, void *f, u32 c) {} void VIDEO_SetNextFramebuffer(void *f) {}
void VIDEO_SetBlack(int b) {} void VIDEO_Flush(void) {} void VIDEO_WaitVSync(void) {} s32 CON_Init(void *a, int b, int c, int d, int e, int f) { return 0; }
u32 sim_down = 0, sim_held = 0; int sim_sy = 0;
void PAD_Init(void) {} void (*sim_script)(void) = 0; u32 PAD_ScanPads(void) { if (sim_script) sim_script(); return 0; } u32 sim_downc[4]; int sim_motor[4], sim_motor_n; u32 PAD_ButtonsDown(int c) { if (c) { u32 d = sim_downc[c & 3]; sim_downc[c & 3] = 0; return d; } u32 d = sim_down; sim_down = 0; return d; } void PAD_ControlMotor(s32 c, u32 cmd) { sim_motor[c & 3] = (int)cmd; if (cmd == 1) sim_motor_n++; } u32 PAD_ButtonsHeld(int c) { return sim_held; }
int sim_my = 0; s8 PAD_StickY(int c) { return (s8)sim_my; } s8 PAD_SubStickY(int c) { return (s8)sim_sy; }
int sim_sx = 0; int sim_mx = 0; s8 PAD_StickX(int c) { return (s8)sim_mx; } s8 PAD_SubStickX(int c) { return (s8)sim_sx; }
u32 VIDEO_HaveComponentCable(void) { return 0; } u32 VIDEO_GetCurrentTvMode(void) { return 0; }
GXRModeObj TVNtsc480Prog, TVEurgb60Hz480Prog, TVPal528IntDf, TVEurgb60Hz480IntDf, TVMpal480IntDf, TVNtsc480IntDf;
void DCFlushRange(void *p, u32 n) {} void AUDIO_InitDMA(u32 a, u32 b) {} u32 IRQ_Disable(void) { return 0; } void IRQ_Restore(u32 l) {}
void AUDIO_Init(u8 *p) {} void AUDIO_SetDSPSampleRate(u8 r) {} void AUDIO_RegisterDMACallback(void (*f)(void)) {} void AUDIO_StartDMA(void) {} void AUDIO_StopDMA(void) {}
#include <time.h>
u64 gettime(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (u64)t.tv_sec * 1000 + t.tv_nsec / 1000000; } int fatMountSimple(const char *a, const DISC_INTERFACE *b) { return 1; }
const DISC_INTERFACE __io_gcsd2, __io_gcsda, __io_gcsdb;


u32 VIDEO_GetRetraceCount(void) { return (u32)(gettime() / 16); }
VIRetraceCallback VIDEO_SetPostRetraceCallback(VIRetraceCallback cb) { return 0; }
/* thread reseau : execute immediatement */
#include <pthread.h>
s32 LWP_CreateThread(lwp_t *t, void *(*entry)(void *), void *arg, void *stack, u32 size, u8 prio) {
    if (entry == net_thread) { entry(arg); return 0; }
    pthread_t th; pthread_create(&th, NULL, entry, arg); pthread_detach(th); return 0; }
