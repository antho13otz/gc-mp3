#!/bin/sh
# build.sh test.c sdroot [extra flags]
t=$1; sd=$2; shift 2
gcc -O1 -g -w -fsanitize=address,undefined -DSD_ROOT="\"$sd\"" "$@" -I. -I../web/source -I../web/helix -I../web/source/helixstub -I../web/gme -I../web/webp -I../web/xmp/include -DLIBXMP_STATIC -I../ext/mbedtls/include -DMBEDTLS_USER_CONFIG_FILE='"gc_tls_config.h"' -DUSE_DEFAULT_STDLIB -D__POWERPC__ $t simnet.c codecs_asan.o mbed_host.a helix_asan.a gme_asan.a xmp_asan.a webp_asan.a -lstdc++ -lm -lpthread -o ${t%.c}_r
