/* v74 : essai EN VRAI de toutes les fonctions reseau (a lancer sur une machine qui a Internet :
   GitHub Actions). Chaque ligne "RESULTAT" dit si la fonction marche. */
#include "simcore.c"
static int nok = 0, nko = 0;
static void res(int ok, const char *what, const char *fmt, ...) {
    char b[600]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof b, fmt, a); va_end(a);
    printf("RESULTAT %s  %-28s %s\n", ok ? "OK  " : "KO  ", what, b); fflush(stdout);
    if (ok) nok++; else nko++;
}
static void pump_all(void) {
    stream_pump(); radio_repair_ok(); radio_last_note(); radio_repair_pump();
    rb_pump(); podcast_pump(); infos_pump(); cover_async_pump(); cover_pump(); lyrics_pump();
    web_pump(); update_pump(); x73_pump(); music_pump(); dltab_pump();
    static u64 tl = 0; u64 n = now_ms(); if (!tl) tl = n;
    int need = (int)((n - tl) * 48); tl = n;
    if ((src == SRC_RADIO && state == ST_PLAY) || (src == SRC_FILE && playing)) for (int i = 0; i < need && f_count > 0; i++) { f_head = (f_head + 1) % FIFO_SIZE; f_count--; consumed++; }
    usleep(3000);
}
#define RUN(secs, until) do { u64 _t0 = now_ms(); while (now_ms() - _t0 < (u64)((secs) * 1000) && !(until)) pump_all(); } while (0)
static long decoded = 0;
static hfetch_t pbh = { .c = { -1, 0, 0 } };
static void probe(const char *url, const char *acc) {
    pbh.image = 0; pbh.maxbytes = 4 << 20; pbh.accept = acc;
    hf_start(&pbh, url, NULL);
    { u64 _t = now_ms(); while (now_ms() - _t < 20000 && pbh.st != HF_DONE && pbh.st != HF_FAIL) { hf_pump(&pbh); usleep(3000); } }
    char snip[260] = ""; int n = 0;
    for (int i = 0; pbh.st == HF_DONE && i < pbh.len && n < 250; i++) { unsigned char c = pbh.buf[i]; snip[n++] = c < 32 ? ' ' : c; }
    snip[n] = 0;
    printf("SONDE %s  code %d  %d octets  %s\n      %s\n", pbh.st == HF_DONE ? "ok" : "ECHEC", pbh.code, pbh.st == HF_DONE ? pbh.len : 0, url, snip);
    hf_drop(&pbh); pbh.st = HF_IDLE;
}
/* une radio : elle doit jouer (son decode) en moins de 20 s */
static void try_station(const char *name, const char *url) {
    snprintf(stations[nstations].name, sizeof stations[0].name, "%s", name);
    snprintf(stations[nstations].url, sizeof stations[0].url, "%s", url);
    now_title[0] = 0; err_msg[0] = 0;
    u64 t0 = now_ms();
    start_station(nstations, 0);
    RUN(20, state == ST_PLAY && consumed > 48000 * 3);
    u64 t1 = now_ms();
    RUN(4, 0);                                   /* (titre ICY) */
    static const char *const cn[] = { "MP3", "AAC", "OGG", "M4A" };
    res(state == ST_PLAY && consumed > 48000 * 3, name, "%s  %.1f s  codec %s  titre '%.60s'  err '%s'  finale %.80s",
        url, (t1 - t0) / 1000.0, cn[stream_codec & 3], now_title, err_msg, http_final_url);
    stop_station();
}

int main(void) {
    setvbuf(stdout, NULL, _IOLBF, 0); outname = "/dev/null"; decode_i4(); init_video(); gx_init();
    system("rm -rf r_net && mkdir -p r_net/mp3 r_net/gc-mp3");
    system("cp 'r_sdA/mp3/Album/01 piste.mp3' 'r_net/mp3/Daft Punk - One More Time.mp3'");
    sd_ok = 1;
    load_settings(); load_stations(); scan_files();
    net_start_async(); while (net_phase != NET_DONE) usleep(10000);
    res(net_ok, "reseau", "ip %s passerelle %s", ip_str, gw_str);

    printf("\n== DNS et HTTPS (certificats) ==\n");
    static const char *const hosts[] = { "api.open-meteo.com", "geocoding-api.open-meteo.com", "lrclib.net", "musicbrainz.org", "coverartarchive.org",
        "itunes.apple.com", "all.api.radio-browser.info", "de1.api.radio-browser.info", "de2.api.radio-browser.info", "fi1.api.radio-browser.info",
        "api.github.com", "www.francetvinfo.fr", "archive.org", "www.mojeek.com", "radiofrance-podcast.net", "github.com", "objects.githubusercontent.com",
        "icecast.radiofrance.fr", "fr.wikipedia.org", NULL };
    for (int i = 0; hosts[i]; i++) {
        u32 a = 0; u64 t0 = now_ms();
        int d = resolve_host(hosts[i], &a);
        conn_t c = { .fd = -1 };
        const char *err = "-"; int refused = 0;
        int ok = d && conn_open(&c, hosts[i], 443, 1, &err, &refused);
        res(ok, hosts[i], "DNS %s  TLS %s  %.1f s  (TLS 1.%d)", d ? "ok" : "ECHEC", ok ? "ok" : err, (now_ms() - t0) / 1000.0,
            ok ? (mbedtls_ssl_get_version_number(&c.ssl) == MBEDTLS_SSL_VERSION_TLS1_3 ? 3 : 2) : 0);
        conn_close(&c);
    }

    printf("\n== Radios de la liste par defaut ==\n");
    int n0 = nstations;
    for (int k = 0; k < n0; k++) try_station(stations[k].name, stations[k].url);

    printf("\n== Annuaire des radios ==\n");
    rb_search("countrycode=FR", "France");
    RUN(25, rb_state == RB_DONE || rb_state == RB_ERROR);
    res(rb_state == RB_DONE && rb_n > 10, "annuaire : populaires FR", "%d radios (serveur %d)", rb_n, rb_server);
    rb_search_name("fip");
    RUN(25, rb_state == RB_DONE || rb_state == RB_ERROR);
    res(rb_state == RB_DONE && rb_n > 0, "annuaire : recherche fip", "%d radios", rb_n);
    rb_search("countrycode=FR", "France");
    RUN(25, rb_state == RB_DONE || rb_state == RB_ERROR);
    {   /* un de chaque sorte : MP3, AAC, OGG, HLS, https */
        const char *want[] = { "MP3", "AAC", "OGG", "HLS", "HTTPS" };
        for (int w = 0; w < 5; w++) {
            int f = -1;
            for (int i = 0; i < rb_n && f < 0; i++) {
                rbres_t *r = &rb_res[i];
                if (w == 3 ? r->hls : w == 4 ? (!strncmp(r->url, "https", 5) && !r->hls) : (!r->hls && !strncasecmp(r->codec, want[w], 3))) f = i;
            }
            char nm[80]; snprintf(nm, sizeof nm, "annuaire %s", want[w]);
            if (f < 0) { printf("  (pas de radio %s dans les resultats)\n", want[w]); continue; }
            char nm2[120]; snprintf(nm2, sizeof nm2, "%s : %.40s", nm, rb_res[f].name);
            try_station(nm2, rb_res[f].url);
        }
        rb_mode = 0;
    }

    probe("https://all.api.radio-browser.info/json/servers", "application/json");
    rb_search("codec=OGG", "OGG");
    RUN(25, rb_state == RB_DONE || rb_state == RB_ERROR);
    if (rb_n) try_station("annuaire OGG", rb_res[0].url); else printf("  (aucune radio OGG)\n");
    rb_mode = 0;

    printf("\n== Reparation d'une radio (adresse perimee) ==\n");
    {
        err_msg[0] = 0; radio_note[0] = 0;
        int k = nstations;
        snprintf(stations[k].name, sizeof stations[0].name, "FIP");
        snprintf(stations[k].url, sizeof stations[0].url, "http://icecast.radiofrance.fr/fip-nexistepas-v74.mp3");
        nstations++;
        start_station(k, 0);
        RUN(70, state == ST_PLAY && consumed > 48000 * 2);
        res(state == ST_PLAY, "reparation 404", "etat %d  url maintenant %s  note '%s'  err '%s'", state, stations[k].url, radio_note, err_msg);
        stop_station();
        nstations--;
    }

    printf("\n== Podcasts ==\n");
    pods_load();
    for (int i = 0; i < npods; i++) {
        pod_open_feed(i);
        RUN(30, pf_state == PF_IDLE);
        res(neps > 0, "podcast (flux)", "%s : %d episodes, 1er '%.50s' %s", pods[i].name, neps, neps ? eps[0].title : "", neps ? eps[0].url : "");
    }
    if (npods) {
        pod_open_feed(0); RUN(30, pf_state == PF_IDLE);
        if (neps) {
            podcast_play(&eps[0]);
            RUN(25, state == ST_PLAY && consumed > 48000 * 3);
            res(state == ST_PLAY && consumed > 48000 * 3, "podcast (ecoute)", "'%s'  err '%s'  finale %.90s", eps[0].title, err_msg, http_final_url);
            podcast_skip(600); RUN(25, state == ST_PLAY && consumed > 48000 * 2);
            res(state == ST_PLAY, "podcast (avance 10 min)", "position %d s  err '%s'", pod_pos_sec(), err_msg);
            ts_speed = 150; consumed = 0; RUN(8, 0);
            res(state == ST_PLAY && ts_want, "podcast (x1,5)", "position %d s  etat %d  ts_want %d  pod_on %d src %d err '%s'", pod_pos_sec(), state, ts_want, pod_on, src, err_msg);
            ts_speed = 100;
            stop_station(); pod_on = 0;
            int e = neps > 1 ? neps - 1 : 0;                 /* (le plus ancien : souvent court) */
            podcast_download(&eps[e]);
            RUN(240, !dl_active && now_ms() > 0);
            RUN(2, 0);
            system("ls -la r_net/gc-mp3/podcasts 2>&1 | tail -3");
            int found = 0; DIR *d = opendir("r_net/gc-mp3/podcasts"); struct dirent *de; while (d && (de = readdir(d))) if (de->d_name[0] != '.' && strcmp(de->d_name, "telecharges.txt")) found++; if (d) closedir(d);
            res(found > 0, "podcast (telechargement)", "%d fichier(s), msg '%s'", found, web_msg);
        }
    }
    { char u[300]; snprintf(u, sizeof u, ITUNES_BASE "/search?media=podcast&entity=podcast&country=%s&limit=40&term=france%%20culture", lang_country()); probe(u, "application/json"); }
    podcast_search("france culture");
    RUN(25, pf_state == PF_IDLE);
    res(npsr > 0, "podcast (recherche iTunes)", "%d resultats, 1er '%s' %s", npsr, npsr ? psr[0].name : "", npsr ? psr[0].url : "");
    if (npsr) {
        snprintf(pods[npods].name, sizeof pods[0].name, "%s", psr[0].name); snprintf(pods[npods].url, sizeof pods[0].url, "%s", psr[0].url); npods++;
        pod_open_feed(npods - 1); RUN(30, pf_state == PF_IDLE);
        res(neps > 0, "podcast (flux trouve)", "%d episodes", neps);
    }

    printf("\n== Pochettes et paroles automatiques ==\n");
    covers_auto = 1; lyrics_auto = 1;
    for (int k = 0; k < nfiles; k++) if (strstr(names[k], "One More Time")) {
        queue_build(k); start_track(k); dur_cache[k] = 320;
        RUN(30, cl_state == CL_DONE && (ly_state == LY_DONE));
        res(cover_ok, "pochette (MusicBrainz)", "album '%s' (%s)  etat %d", cl_album, cl_year, cl_state);
        probe(MB_BASE "/ws/2/recording/?query=recording%3A%22One%20More%20Time%22%20AND%20artist%3A%22Daft%20Punk%22&limit=5&fmt=json", "application/json");
        long l; res(read_file("r_net/mp3/Daft Punk - One More Time.lrc", 1 << 20, &l) != NULL, "paroles (LRCLIB)", "%d lignes", lrc_n);
        stop_track();
    }
    rhc_want("Daft Punk - One More Time");
    RUN(25, rhc_n == 0 && rhc_state == 0 && rhc_known("Daft Punk - One More Time"));
    res(rhc_known("Daft Punk - One More Time") == 1, "pochette d'un titre radio", "iTunes");

    printf("\n== Meteo et actualites ==\n");
    snprintf(city, sizeof city, "Marseille"); meteo_t = 0; meteo_ok = 0; tab = TAB_INFO;
    RUN(30, meteo_ok && nnews > 0);
    res(meteo_ok, "meteo (open-meteo)", "%s : %.1f deg, code %d, vent %d, %d jours", geo_name, meteo_temp, meteo_code, meteo_wind, ndays);
    res(nnews > 0, "actualites (RSS)", "%d titres, 1er '%.60s'", nnews, nnews ? news_title[0] : "");
    tab = TAB_MUSIC;

    printf("\n== Mise a jour (GitHub) ==\n");
    update_check();
    RUN(30, up_state != UP_CHECK);
    res(up_state == UP_AVAIL || up_state == UP_NONE, "mise a jour", "etat %d build %d  %s  %s", up_state, up_build, up_url, up_msg);
    if (up_state == UP_AVAIL) {
        snprintf(upd_file, sizeof upd_file, "r_net/gc-mp3player.dol");
        update_start_download();
        RUN(120, up_state != UP_DL && up_state != UP_WRITE);
        long l = 0; unsigned char *d = read_file("r_net/gc-mp3player.dol", 32 << 20, &l); free(d);
        res(up_state == UP_DONE && l > 1000000, "mise a jour (telechargement)", "etat %d, %ld octets, %s", up_state, l, up_msg);
    }

    printf("\n== Navigateur web ==\n");
    {
        tab = TAB_WEB;
        const char *pages[] = { "https://www.mojeek.com/search?q=gamecube", "https://html.duckduckgo.com/html/?q=gamecube", "https://lite.duckduckgo.com/lite/?q=gamecube",
            "https://www.bing.com/search?q=gamecube", "https://search.marginalia.nu/search?query=gamecube", "https://www.startpage.com/do/search?q=gamecube",
            "https://search.brave.com/search?q=gamecube", "https://www.google.com/search?q=gamecube&gbv=1", "https://www.ecosia.org/search?q=gamecube",
            "https://fr.wikipedia.org/wiki/GameCube", "http://info.cern.ch/", "https://example.com/", "https://www.francetvinfo.fr/", "https://news.ycombinator.com/", NULL };
        for (int i = 0; pages[i]; i++) {
            web_fetch(pages[i], NAV_PUSH, 1);
            RUN(30, !wb_loading && !wb_busy);
            RUN(12, 0);
            if (strstr(pages[i], "example.com") && pg.src) printf("      HTML : %.1200s\n", (const char *)pg.src);
            if (strstr(pages[i], "francetvinfo.fr") || strstr(pages[i], "wikipedia")) for (int k = 0; k < nwimg && k < 8; k++) printf("      image %d : etat %d  y %d  %.150s\n", k, wimgs[k].st, (int)wimgs[k].y0, wimgs[k].url ? wimgs[k].url : "");
            if (strstr(pages[i], "example.com")) for (int k = 0; k < pg.nitems && k < 12; k++) printf("      element %d : style %d lien %d %.80s\n", k, pg.items[k].style, pg.items[k].link, pg.text + pg.items[k].off);
            int imgs = 0; for (int k = 0; k < nwimg; k++) imgs += wimgs[k].st == IMG_OK;
            res(pg.nitems > 5, "web", "%s : %d elements, %d liens, %d/%d images, titre '%.50s'  msg '%s'", pages[i], pg.nitems, pg.nlinks, imgs, nwimg, pg.title, web_msg);
        }
        web_search("gamecube"); RUN(30, !wb_loading && !wb_busy); RUN(2, 0);
        res(pg.nlinks > 10, "recherche web", "%s : %d liens  titre '%.50s'  msg '%s'", wb_url, pg.nlinks, pg.title, web_msg);
        snprintf(ws_q, sizeof ws_q, "gamecube"); web_fetch("https://www.mojeek.com/search?q=gamecube", NAV_PUSH, 0); RUN(30, !wb_loading && !wb_busy); RUN(2, 0);
        res(pg.nlinks > 10, "recherche web (repli)", "%s : %d liens  titre '%.50s'  msg '%s'", wb_url, pg.nlinks, pg.title, web_msg);
        web_archive_search("chiptune");
        RUN(30, !wb_loading && !wb_busy); RUN(2, 0);
        res(pg.nlinks > 5, "archive.org (recherche)", "%d liens  titre '%.50s'  msg '%s'", pg.nlinks, pg.title, web_msg);
    }

    printf("\nFIN : %d OK, %d KO\n", nok, nko);
    return 0;
}
