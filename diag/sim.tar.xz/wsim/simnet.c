#include "network.h"
#include <stdlib.h>
#include <string.h>
int sim_dhcp_ok = 1;
s32 if_config(char *ip, char *mask, char *gw, int dhcp, int r) {
    if (!sim_dhcp_ok) return -2;
    strcpy(ip, "192.168.1.42"); strcpy(mask, "255.255.255.0"); strcpy(gw, getenv("SIM_GW") ? getenv("SIM_GW") : "127.0.0.1"); return 0; }
s32 net_socket(u32 d, u32 t, u32 p) { int s = socket(AF_INET, t == 2 ? SOCK_DGRAM : SOCK_STREAM, 0); return s < 0 ? -errno : s; }
s32 net_connect(s32 s, struct sockaddr *a, socklen_t l) { return connect(s, a, l) < 0 ? -errno : 0; }
s32 net_send(s32 s, const void *d, s32 n, u32 f) { ssize_t r = send(s, d, n, MSG_NOSIGNAL); return r < 0 ? -errno : (s32)r; }
s32 net_recv(s32 s, void *m, s32 n, u32 f) { ssize_t r = recv(s, m, n, 0); return r < 0 ? -errno : (s32)r; }
s32 net_sendto(s32 s, const void *d, s32 n, u32 f, struct sockaddr *to, socklen_t tl) { ssize_t r = sendto(s, d, n, 0, to, tl); return r < 0 ? -errno : (s32)r; }
s32 net_recvfrom(s32 s, void *m, s32 n, u32 f, struct sockaddr *fr, socklen_t *fl) { ssize_t r = recvfrom(s, m, n, 0, fr, fl); return r < 0 ? -errno : (s32)r; }
s32 net_close(s32 s) { return close(s); }
s32 net_ioctl(s32 s, u32 cmd, void *arg) { int v = *(u32 *)arg; return ioctl(s, FIONBIO, &v); }
#ifndef PHONE_TEST_PORT
#define PHONE_TEST_PORT 8150
#endif
s32 net_bind(s32 s, struct sockaddr *a, socklen_t l) {
    struct sockaddr_in *in = (struct sockaddr_in *)a;
    if (ntohs(in->sin_port) == 80) in->sin_port = htons(PHONE_TEST_PORT);   /* pas le port 80 sur le PC */
    return bind(s, a, l) < 0 ? -errno : 0; }
s32 net_listen(s32 s, u32 b) { return listen(s, b) < 0 ? -errno : 0; }
s32 net_accept(s32 s, struct sockaddr *a, socklen_t *l) { int r = accept(s, a, l); return r < 0 ? -errno : r; }
s32 net_setsockopt(s32 s, u32 level, u32 opt, const void *v, socklen_t l) { int one = 1; return setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one) < 0 ? -errno : 0; }
