/* Reseau libogc simule avec les sockets du PC */
#pragma once
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <gccore.h>
s32 if_config(char *ip, char *mask, char *gw, int dhcp, int retries);
s32 net_socket(u32 d, u32 t, u32 p);
s32 net_connect(s32 s, struct sockaddr *a, socklen_t l);
s32 net_send(s32 s, const void *d, s32 n, u32 f);
s32 net_recv(s32 s, void *m, s32 n, u32 f);
s32 net_sendto(s32 s, const void *d, s32 n, u32 f, struct sockaddr *to, socklen_t tl);
s32 net_recvfrom(s32 s, void *m, s32 n, u32 f, struct sockaddr *fr, socklen_t *fl);
s32 net_close(s32 s);
s32 net_ioctl(s32 s, u32 cmd, void *arg);
s32 net_bind(s32 s, struct sockaddr *a, socklen_t l);
s32 net_listen(s32 s, u32 b);
s32 net_accept(s32 s, struct sockaddr *a, socklen_t *l);
s32 net_setsockopt(s32 s, u32 level, u32 opt, const void *v, socklen_t l);
