/* simulateur : un clavier GameCube emule sur un port */
#pragma once
#define SI_GC_KEYBOARD 0x08200000u
typedef void (*SICallback)(s32, u32);
static int sim_kb_chan = -1;
static u8 sim_kb_keys[3];
static u8 sim_kb_counter;
static inline u32 SI_GetType(s32 ch) { return ch == sim_kb_chan ? SI_GC_KEYBOARD : 0x08u; }
static inline u32 SI_DecodeType(u32 t) { return t == SI_GC_KEYBOARD ? SI_GC_KEYBOARD : 0x40u; }
static inline u32 SI_Transfer(s32 ch, void *out, u32 ol, void *in, u32 il, SICallback cb, u32 d) {
    (void)out; (void)ol; (void)il; (void)d;
    u8 *b = (u8 *)in;
    if (ch != sim_kb_chan) { cb(ch, 0x08); return 1; }
    sim_kb_counter = (sim_kb_counter + 1) & 15;
    b[0] = sim_kb_counter; b[1] = b[2] = b[3] = 0;
    b[4] = sim_kb_keys[0]; b[5] = sim_kb_keys[1]; b[6] = sim_kb_keys[2];
    b[7] = (u8)(b[4] ^ b[5] ^ b[6] ^ sim_kb_counter);
    cb(ch, 0);
    return 1;
}
