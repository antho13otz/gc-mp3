#pragma once
#include <gccore.h>
u64 gettime(void);
#define ticks_to_millisecs(t) (t)
