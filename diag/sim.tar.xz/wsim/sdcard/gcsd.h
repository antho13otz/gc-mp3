#pragma once
#include <fat.h>
extern const DISC_INTERFACE __io_gcsd2, __io_gcsda, __io_gcsdb;
