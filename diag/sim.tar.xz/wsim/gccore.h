/* En-tetes factices pour simuler GX sur PC (rendu logiciel). */
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32; typedef float f32;
typedef f32 Mtx44[4][4]; typedef f32 Mtx[3][4];
typedef struct { u8 r,g,b,a; } GXColor;
typedef struct { u32 dummy[8]; } GXTexObj;
typedef struct { u32 viTVMode; u16 fbWidth, efbHeight, xfbHeight, viXOrigin, viYOrigin, viWidth, viHeight; u32 xfbMode; u8 field_rendering, aa; u8 sample_pattern[12][2]; u8 vfilter[7]; } GXRModeObj;
#define ATTRIBUTE_ALIGN(n) __attribute__((aligned(n)))
#define TRUE 1
#define FALSE 0
#define VI_NON_INTERLACE 1
#define VI_DISPLAY_PIX_SZ 2
#define COLOR_BLACK 0x00800080
#define MEM_K0_TO_K1(x) ((void*)(x))
enum { GX_FALSE=0, GX_TRUE=1, GX_DISABLE=0, GX_ENABLE=1,
 GX_QUADS=0x80, GX_TRIANGLES=0x90, GX_TRIANGLESTRIP=0x98, GX_TRIANGLEFAN=0xA0,
 GX_VTXFMT0=0, GX_ALWAYS=7, GX_BM_NONE=0, GX_BM_BLEND=1, GX_BL_ONE=1, GX_BL_ZERO=0, GX_BL_SRCALPHA=4, GX_BL_INVSRCALPHA=5, GX_LO_CLEAR=0,
 GX_CULL_NONE=0, GX_COLOR0A0=4, GX_SRC_VTX=1, GX_DF_NONE=0, GX_AF_NONE=2, GX_TEVSTAGE0=0, GX_PASSCLR=4,
 GX_TEXCOORDNULL=0xff, GX_TEXMAP_NULL=0xff, GX_TEXCOORD0=0, GX_TEXMAP0=0, GX_TG_MTX2x4=1, GX_TG_TEX0=4, GX_IDENTITY=60,
 GX_CC_ZERO=15, GX_CC_RASC=10, GX_CA_ZERO=7, GX_CA_TEXA=4, GX_CA_RASA=5, GX_TEV_ADD=0, GX_TB_ZERO=0, GX_CS_SCALE_1=0, GX_TEVPREV=0,
 GX_VA_POS=9, GX_VA_CLR0=11, GX_VA_TEX0=13, GX_DIRECT=1, GX_POS_XY=0, GX_F32=4, GX_CLR_RGBA=1, GX_RGBA8=5, GX_TEX_ST=1,
 GX_PF_RGB565_Z16=2, GX_PF_RGB8_Z24=0, GX_ZC_LINEAR=0, GX_GM_1_0=0, GX_ORTHOGRAPHIC=1, GX_PNMTX0=0,
 GX_TF_I4=0, GX_TF_RGB565=4, GX_TF_RGB5A3=5, GX_TEXMAP1=1, GX_TEXMAP2=2, GX_CC_TEXC=8, GX_CLAMP=0, GX_LINEAR=1, AI_SAMPLERATE_48KHZ=1,
 PAD_BUTTON_LEFT=1, PAD_BUTTON_RIGHT=2, PAD_BUTTON_DOWN=4, PAD_BUTTON_UP=8, PAD_TRIGGER_Z=16, PAD_TRIGGER_R=32, PAD_TRIGGER_L=64,
 PAD_BUTTON_A=256, PAD_BUTTON_B=512, PAD_BUTTON_X=1024, PAD_BUTTON_Y=2048, PAD_BUTTON_START=4096 };
void *GX_Init(void*,u32); void GX_SetCopyClear(GXColor,u32); void GX_SetViewport(f32,f32,f32,f32,f32,f32);
f32 GX_GetYScaleFactor(u16,u16); u32 GX_SetDispCopyYScale(f32); void GX_SetScissor(u32,u32,u32,u32);
void GX_SetDispCopySrc(u16,u16,u16,u16); void GX_SetDispCopyDst(u16,u16); void GX_SetCopyFilter(u8,u8(*)[2],u8,u8*);
void GX_SetFieldMode(u8,u8); void GX_SetPixelFmt(u8,u8); void GX_SetCullMode(u8); void GX_SetDispCopyGamma(u8);
void guOrtho(Mtx44,f32,f32,f32,f32,f32,f32); void GX_LoadProjectionMtx(Mtx44,u8); void guMtxIdentity(Mtx);
void GX_LoadPosMtxImm(Mtx,u32); void GX_SetCurrentMtx(u32); void GX_SetZMode(u8,u8,u8); void GX_SetBlendMode(u8,u8,u8,u8);
void GX_SetColorUpdate(u8); void GX_SetAlphaUpdate(u8); void GX_SetNumChans(u8); void GX_SetChanCtrl(s32,u8,u8,u8,u8,u8,u8);
void GX_SetNumTevStages(u8); void GX_ClearVtxDesc(void); void GX_SetVtxDesc(u8,u8); void GX_SetVtxAttrFmt(u8,u32,u32,u32,u32);
void GX_InitTexObj(GXTexObj*,void*,u16,u16,u8,u8,u8,u8); void GX_InitTexObjFilterMode(GXTexObj*,u8,u8);
void GX_InvalidateTexAll(void); void GX_LoadTexObj(GXTexObj*,u8); void GX_InvVtxCache(void);
void GX_SetNumTexGens(u32); void GX_SetTevOrder(u8,u8,u32,u8); void GX_SetTevOp(u8,u8); void GX_SetTexCoordGen(u16,u32,u32,u32);
void GX_SetTevColorIn(u8,u8,u8,u8,u8); void GX_SetTevColorOp(u8,u8,u8,u8,u8,u8); void GX_SetTevAlphaIn(u8,u8,u8,u8,u8); void GX_SetTevAlphaOp(u8,u8,u8,u8,u8,u8);
void GX_Begin(u8,u8,u16); void GX_End(void); void GX_Position2f32(f32,f32); void GX_Color4u8(u8,u8,u8,u8); void GX_TexCoord2f32(f32,f32);
void GX_DrawDone(void); void GX_CopyDisp(void*,u8);
void VIDEO_Init(void); GXRModeObj *VIDEO_GetPreferredMode(GXRModeObj*); void *SYS_AllocateFramebuffer(GXRModeObj*);
void VIDEO_Configure(GXRModeObj*); void VIDEO_ClearFrameBuffer(GXRModeObj*,void*,u32); void VIDEO_SetNextFramebuffer(void*);
void VIDEO_SetBlack(int); void VIDEO_Flush(void); void VIDEO_WaitVSync(void); s32 CON_Init(void*,int,int,int,int,int);
#define PAD_MOTOR_STOP 0
#define PAD_MOTOR_RUMBLE 1
#define PAD_MOTOR_STOP_HARD 2
void PAD_ControlMotor(s32 chan, u32 cmd);
void PAD_Init(void); u32 PAD_ScanPads(void); u32 PAD_ButtonsDown(int); u32 PAD_ButtonsHeld(int);
void DCFlushRange(void*,u32); void AUDIO_InitDMA(u32,u32); u32 IRQ_Disable(void); void IRQ_Restore(u32);
void AUDIO_Init(u8*); void AUDIO_SetDSPSampleRate(u8); void AUDIO_RegisterDMACallback(void(*)(void)); void AUDIO_StartDMA(void); void AUDIO_StopDMA(void);
typedef void (*GXDrawDoneCallback)(void);
GXDrawDoneCallback GX_SetDrawDoneCallback(GXDrawDoneCallback);
void GX_SetDrawDone(void);
void GX_GetGPStatus(u8*,u8*,u8*,u8*,u8*);
u32 VIDEO_GetRetraceCount(void);
typedef void (*VIRetraceCallback)(u32);
VIRetraceCallback VIDEO_SetPostRetraceCallback(VIRetraceCallback);
typedef u32 lwp_t;
s32 LWP_CreateThread(lwp_t *t, void *(*entry)(void *), void *arg, void *stack, u32 size, u8 prio);
s8 PAD_StickY(int); s8 PAD_SubStickY(int);
s8 PAD_StickX(int); s8 PAD_SubStickX(int);
u32 VIDEO_HaveComponentCable(void); u32 VIDEO_GetCurrentTvMode(void);
extern GXRModeObj TVNtsc480Prog, TVEurgb60Hz480Prog, TVPal528IntDf, TVEurgb60Hz480IntDf, TVMpal480IntDf, TVNtsc480IntDf;
#define VI_PAL 1
#ifndef VI_NTSC
#define VI_NTSC 0
#endif
#define SYS_LANG_ENGLISH 0
#define SYS_LANG_GERMAN 1
#define SYS_LANG_FRENCH 2
#define SYS_LANG_SPANISH 3
#define SYS_LANG_ITALIAN 4
#define SYS_LANG_DUTCH 5
u8 SYS_GetLanguage(void);
void SYS_SetLanguage(u8 l);
#define SYS_SOUND_MONO 0
#define SYS_SOUND_STEREO 1
u8 SYS_GetSoundMode(void); void SYS_SetSoundMode(u8 m);
s8 SYS_GetDisplayOffsetH(void); void SYS_SetDisplayOffsetH(s8 o);
void VIDEO_SetAdjustingValues(s16 h, s16 v);
void *SYS_GetArena1Lo(void); void *SYS_GetArena1Hi(void);
#include <stdbool.h>
/* cartes memoire (v35) */
#define CARD_SLOTA 0
#define CARD_SLOTB 1
#define CARD_WORKAREA_SIZE (5*8*1024)
#define CARD_FILENAMELEN 32
#define CARD_MAXFILES 127
#define CARD_ERROR_READY 0
#define CARD_ERROR_BUSY -1
#define CARD_ERROR_WRONGDEVICE -2
#define CARD_ERROR_NOCARD -3
#define CARD_ERROR_NOFILE -4
#define CARD_ERROR_IOERROR -5
#define CARD_ERROR_BROKEN -6
#define CARD_ERROR_EXIST -7
#define CARD_ERROR_NOENT -8
#define CARD_ERROR_INSSPACE -9
#define CARD_ERROR_NOPERM -10
#define CARD_ERROR_ENCODING -13
#define CARD_ERROR_FATAL_ERROR -128
typedef void (*cardcallback)(s32 chan, s32 result);
typedef struct _card_file { s32 chn; s32 filenum; s32 offset; s32 len; u16 iblock; } card_file;
typedef struct _card_dir { s32 chn; u32 fileno; u32 filelen; u8 permissions; char filename[CARD_FILENAMELEN]; u8 gamecode[4]; u8 company[2]; bool showall; } card_dir;
typedef struct _card_direntry { u8 gamecode[4]; u8 company[2]; u8 pad_00; u8 banner_fmt; u8 filename[CARD_FILENAMELEN]; u32 last_modified; u32 icon_addr; u16 icon_fmt; u16 icon_speed; u8 permission; u8 copy_times; u16 block; u16 length; u16 pad_01; u32 comment_addr; } card_direntry;
s32 CARD_Init(const char *gamecode, const char *company);
s32 CARD_Mount(s32 chn, void *workarea, cardcallback detach_cb);
s32 CARD_Unmount(s32 chn);
s32 CARD_Read(card_file *file, void *buffer, u32 len, u32 offset);
s32 CARD_Write(card_file *file, void *buffer, u32 len, u32 offset);
s32 CARD_OpenEntry(s32 chn, card_dir *entry, card_file *file);
s32 CARD_Close(card_file *file);
s32 CARD_Create(s32 chn, const char *filename, u32 size, card_file *file);
s32 CARD_DeleteEntry(s32 chn, card_dir *dir_entry);
s32 CARD_FindFirst(s32 chn, card_dir *dir, bool showall);
s32 CARD_FindNext(card_dir *dir);
s32 CARD_GetSectorSize(s32 chn, u32 *sector_size);
s32 CARD_GetStatusEx(s32 chn, s32 fileno, card_direntry *entry);
s32 CARD_SetStatusEx(s32 chn, s32 fileno, card_direntry *entry);
s32 CARD_SetCompany(const char *company);
s32 CARD_SetGamecode(const char *gamecode);
s32 CARD_GetFreeBlocks(s32 chn, u16 *freeblocks);
#define VI_EURGB60 5
#define VI_PROGRESSIVE 2
#define VI_MPAL 2
